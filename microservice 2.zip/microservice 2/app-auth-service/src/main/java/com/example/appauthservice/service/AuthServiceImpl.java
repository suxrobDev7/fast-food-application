package com.example.appauthservice.service;

import com.example.appauthservice.common.UserPrincipal;
import com.example.appauthservice.exception.SendingVerificationException;
import com.example.appauthservice.payload.*;
import com.example.appauthservice.repository.RoleRepository;
import com.example.appauthservice.repository.UserRepository;
import com.example.appauthservice.repository.VerificationCodeRepository;
import com.example.appauthservice.security.JWTProvider;
import com.example.appdbservice.entity.users.Role;
import com.example.appdbservice.entity.users.User;
import com.example.appdbservice.entity.users.VerificationCode;
import com.example.appdbservice.exception.RestException;
import com.example.appdbservice.payload.ApiResult;
import com.example.appdbservice.utils.AppConstant;
import io.jsonwebtoken.ExpiredJwtException;
import com.example.appdbservice.entity.enums.Permissions;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final RoleRepository roleRepository;
    private final AuthenticationManager authenticationManager;
    private final JWTProvider jwtProvider;
    private final VerificationCodeRepository verificationCodeRepository;
    private final TwilioService twilioService;

    @Value("${codeLimit}")
    private int codeLimit;
    @Value("${codeTime}")
    private long verificationCodeTime;

    @Override
    public ApiResult<?> signUp(RegisterDTO registerDTO) {
        checkPhoneNumber(registerDTO.getPhoneNumber());
        Role role = roleRepository.findByName(AppConstant.USER_ROLE).orElseThrow(()
                -> RestException.notFound("Role"));
        UserPrincipal userPrincipal = new UserPrincipal(
                new User(
                        registerDTO.getFirstName(),
                        registerDTO.getLastName(),
                        registerDTO.getPhoneNumber(),
                        registerDTO.getDistrictId(),
                        registerDTO.getAvatarId(),
                        passwordEncoder.encode(registerDTO.getPassword()),
                        registerDTO.getLanguage(),
                        true,
                        role
                ));
        userRepository.save(userPrincipal.getUser());
//        sendPhoneNumber(userPrincipal.getUser());
        String accessToken = jwtProvider.generateAccessToken(String.valueOf(userPrincipal.getUser().getId()));
        String refreshToken = jwtProvider.generateRefreshToken(String.valueOf(userPrincipal.getUser().getId()));
        return ApiResult.successResponse(new TokenDTO(accessToken, refreshToken));
    }

    @Override
    public ApiResult<TokenDTO> signIn(SignInDTO signInDTO) {
        try {
            Authentication authenticate = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            signInDTO.getUsername(),
                            signInDTO.getPassword()
                    )
            );
            UserPrincipal userPrincipal = (UserPrincipal) authenticate.getPrincipal();
            String accessToken = jwtProvider.generateAccessToken(String.valueOf(userPrincipal.getUser().getId()));
            String refreshToken = jwtProvider.generateRefreshToken(String.valueOf(userPrincipal.getUser().getId()));
            TokenDTO tokenDTO = new TokenDTO(accessToken, refreshToken);
            return ApiResult.successResponse(tokenDTO);
        } catch (Exception e) {
            e.printStackTrace();
            throw RestException.restThrow("Password or Username is wrong");
        }
    }

    @Override
    public ApiResult<?> confirmAccount(Long userId, String verificationCode) {
        User user = getUserByIdOrElseThrow(userId);
//        if (!Objects.equals(verificationCode, user.getVerificationCode()))
//            throw RestException.restThrow("Wrong code");
//        user.setEnabled(true);
//        userRepository.save(user);
//        return ApiResult.successResponse("Successfully confirmed");
        return null;
    }

    @Override
    public ApiResult<TokenDTO> refreshToken(TokenDTO tokenDTO) {
        try {
            jwtProvider.validateToken(tokenDTO.getAccessToken());
            return ApiResult.successResponse(tokenDTO);
        } catch (ExpiredJwtException e) {
            try {
                jwtProvider.validateToken(tokenDTO.getRefreshToken());
                Long userId = Long.valueOf(jwtProvider.getUsernameFromToken(tokenDTO.getRefreshToken()));
                return ApiResult.successResponse(new TokenDTO(
                        jwtProvider.generateTokenFromId(userId, true),
                        jwtProvider.generateTokenFromId(userId, false)
                ));
            } catch (Exception ex) {
                throw new RestException("Refresh token buzilgan", HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            throw new RestException("Access token buzligan", HttpStatus.UNAUTHORIZED);
        }
    }

    public ApiResult<?> checkPhoneNumber(PhoneNumberDTO phoneNumberDTO) {
        Timestamp pastTime = new Timestamp(System.currentTimeMillis() - verificationCodeTime);
        Long countOfSentCode = verificationCodeRepository.countAllByPhoneNumberAndCreationAtAfter(
                phoneNumberDTO.getPhoneNumber(),
                pastTime
        );
        if (countOfSentCode > codeLimit)
            throw new RestException("Ko'p marotaba sms jo'natildi! Iltimos birozdan keyin urunib ko'ring!", HttpStatus.TOO_MANY_REQUESTS);

        String code = generateVerificationCode();
        boolean verificationCode = twilioService.sendVerificationCode(code,phoneNumberDTO.getPhoneNumber());
        if (!verificationCode)
            throw new SendingVerificationException();
        VerificationCode newVerificationCode = new VerificationCode();
        newVerificationCode.setCode(code);
        newVerificationCode.setPhoneNumber(phoneNumberDTO.getPhoneNumber());
        verificationCodeRepository.save(newVerificationCode);
        return ApiResult.successResponse();
    }

    public ApiResult<User> checkPermission(Permissions permission) {
        try {
            UserPrincipal userPrincipal = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            for (Permissions permissions : userPrincipal.getPermissionEnums()) {
                if (permissions.equals(permission)) {
                    return ApiResult.successResponse(userPrincipal.getUser());
                }
            }
            throw new RestException("Sizga bu yo'lga kirish imkoniyati yo'q",HttpStatus.FORBIDDEN);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RestException("Autorizatsiyadan o'tmagan!",HttpStatus.UNAUTHORIZED);
        }
    }

    public ApiResult<User> checkUser() {
        try {
            UserPrincipal userPrincipal = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            return ApiResult.successResponse(userPrincipal.getUser());
        } catch (Exception e) {
            e.printStackTrace();
            throw new RestException("Autorizatsiyadan o'tmagan!", HttpStatus.UNAUTHORIZED);
        }
    }

    @Override
    public ApiResult<?> checkCode(CodeDTO codeDTO) {
        Timestamp pastTime = new Timestamp(System.currentTimeMillis() - verificationCodeTime);
        VerificationCode verificationCode = verificationCodeRepository.getByCondition(
                codeDTO.getPhoneNumber(),
                codeDTO.getCode(),
                pastTime).orElseThrow(
                () -> new RestException("Xato kod yubordingiz",HttpStatus.BAD_REQUEST)
        );
        Optional<User> userOptional = userRepository.findByPhoneNumber(codeDTO.getPhoneNumber());
        String accessToken = null;
        String refreshToken = null;
        boolean registered = false;
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            user.setEnabled(true);
            userRepository.save(user);
            accessToken = jwtProvider.generateAccessToken(user.getUsername());
            refreshToken = jwtProvider.generateRefreshToken(user.getUsername());
            registered = true;
        }
        verificationCode.setConfirmed(true);
        verificationCodeRepository.save(verificationCode);
        return ApiResult.successResponse(new RegisterTokenDTO(accessToken,refreshToken,registered));
    }


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        try {
            return (UserDetails) userRepository.findByPhoneNumber(username).orElseThrow(() -> RestException.notFound("User"));
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    private void checkPhoneNumber(String phoneNumber) {
        boolean exist = userRepository.existsByPhoneNumber(phoneNumber);
        if (exist) throw RestException.alreadyExist("This phone number is");
    }

    private User getUserByIdOrElseThrow(Long userId) {
        return userRepository.findById(userId).orElseThrow(() -> RestException.notFound("User"));
    }


    private String generateVerificationCode() {
        String code = String.valueOf((long) (Math.random() * 1_000_000_000));
        return code.substring(0, 6);
    }

}
