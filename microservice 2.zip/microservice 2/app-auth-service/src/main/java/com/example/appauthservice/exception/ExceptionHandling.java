package com.example.appauthservice.exception;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionHandling {

    @ExceptionHandler(value = {SendingVerificationException.class})
    public HttpEntity<?> handling() {
        return new HttpEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
