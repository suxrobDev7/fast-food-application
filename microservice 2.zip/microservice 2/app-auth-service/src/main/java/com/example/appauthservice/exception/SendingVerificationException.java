package com.example.appauthservice.exception;

public class SendingVerificationException extends RuntimeException {
}
