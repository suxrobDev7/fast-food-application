package com.example.appauthservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppAuthServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
