package com.example.appdbservice.repository.user;

import com.example.appdbservice.entity.users.Address;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Long> {


    
}
