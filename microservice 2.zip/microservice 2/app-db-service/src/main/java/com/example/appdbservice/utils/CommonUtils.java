package com.example.appdbservice.utils;

import com.example.appdbservice.entity.users.User;
import com.example.appdbservice.exception.RestException;
import org.springframework.http.HttpStatus;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Optional;

public class CommonUtils {

    public static HttpServletRequest currentRequest() {
        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        return Optional.ofNullable(servletRequestAttributes).map(ServletRequestAttributes::getRequest).orElse(null);
    }

    public static User getUserFromRequest() {
        try {
            HttpServletRequest httpServletRequest = currentRequest();
            return (User) httpServletRequest.getAttribute(AppConstant.REQUEST_ATTRIBUTE_CURRENT_USER);
        } catch (Exception e) {

            throw new RestException("UNAUTHORIZED",HttpStatus.UNAUTHORIZED);
        }
    }

}
