package com.example.appdbservice.repository.order;

import com.example.appdbservice.entity.order.BasketSale;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BasketSaleRepository extends JpaRepository<BasketSale,Long> {

}
