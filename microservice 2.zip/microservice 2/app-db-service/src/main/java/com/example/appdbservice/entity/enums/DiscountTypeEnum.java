package com.example.appdbservice.entity.enums;

public enum DiscountTypeEnum {
    PRICE,
    PERCENT;
}
