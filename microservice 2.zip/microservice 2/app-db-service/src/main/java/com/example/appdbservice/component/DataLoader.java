package com.example.appdbservice.component;

import com.example.appdbservice.entity.enums.PayTypeEnum;
import com.example.appdbservice.entity.order.PayType;
import com.example.appdbservice.repository.order.PayTypeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {

    private final PayTypeRepository payTypeRepository;

    @Value("${spring.sql.init.mode}")
    String sqlMode;

    @Override
    public void run(String... args) throws Exception {

        if (sqlMode.equals("always")) {

            List<PayType> payTypes = new ArrayList<>();
            payTypes.add(
                    new PayType(
                            "Payme",
                            PayTypeEnum.PAYME
                    )
            );
            payTypes.add(
                    new PayType(
                            "Click",
                            PayTypeEnum.CLICK
                    )
            );
            payTypes.add(
                    new PayType(
                            "Cash",
                            PayTypeEnum.CASH
                    )
            );
            payTypeRepository.saveAll(payTypes);

        }

    }
}
