package com.example.appdbservice.exception;

public class TokenExpiredException extends RuntimeException {
}
