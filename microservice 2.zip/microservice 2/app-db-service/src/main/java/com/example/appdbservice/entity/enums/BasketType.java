package com.example.appdbservice.entity.enums;

public enum BasketType {

    DRAFT,
    ACCEPTED

}
