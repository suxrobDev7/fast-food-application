package com.example.appdbservice.service;

import com.example.appdbservice.entity.enums.DiscountTypeEnum;
import com.example.appdbservice.entity.order.Basket;
import com.example.appdbservice.entity.order.BasketSale;
import com.example.appdbservice.entity.order.PriceSale;
import com.example.appdbservice.entity.order.Sale;
import com.example.appdbservice.exception.RestException;
import com.example.appdbservice.payload.ApiResult;
import com.example.appdbservice.payload.PriceSaleDTO;
import com.example.appdbservice.payload.SaleAddDTO;
import com.example.appdbservice.repository.order.BasketSaleRepository;
import com.example.appdbservice.repository.order.PriceSaleRepository;
import com.example.appdbservice.repository.order.SaleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;


@Service
@RequiredArgsConstructor
public class PriceSaleServiceImpl implements PriceSaleService {

    private final PriceSaleRepository priceSaleRepository;
    private final SaleServiceImpl saleService;
    private final BasketService basketService;
    private final SaleRepository saleRepository;
    private final BasketSaleRepository basketSaleRepository;


    @Override
    public ApiResult<List<?>> getAll(int page, int size) {
        Pageable pageable = PageRequest.of(page,size);
        Page<PriceSale> priceSalePage = priceSaleRepository.findAll(pageable);
        List<PriceSale> priceSales = priceSalePage.getContent();
        List<PriceSaleDTO> priceSaleDTOS = priceSales
                .stream()
                .map(this::entityToInfoDTO)
                .collect(Collectors.toList());

        return ApiResult.successResponse(priceSaleDTOS);

    }

    @Override
    public ApiResult<?> getOne(Long id) {
        PriceSale sale = getByIdOrElseThrow(id);
        if (Objects.isNull(sale)) {
            throw RestException.notFound("Price sale");
        }
        return ApiResult.successResponse(entityToInfoDTO(sale));
    }

    @Override
    public ApiResult<?> add(PriceSaleDTO saleAddDTO) {
        SaleAddDTO saleAddDTO1 = saleAddDTO.getSaleAddDTO();
        saleService.add(saleAddDTO1);
        PriceSale priceSale = dTOToEntity(saleAddDTO);
        PriceSale save = priceSaleRepository.save(priceSale);
        PriceSaleDTO priceSaleDTO = entityToInfoDTO(save);
        return ApiResult.successResponse(priceSaleDTO);
    }


    @Override
    public ApiResult<?> update(PriceSaleDTO saleUpdateDTO, Long id) {
        PriceSale priceSale = priceSaleRepository.findById(id).orElseThrow(() -> new RestException("Sale", HttpStatus.NOT_FOUND));
        saleService.update(saleUpdateDTO.getSaleAddDTO(),priceSale.getSale().getId());
        updateEntity(saleUpdateDTO, priceSale);
        PriceSale save = priceSaleRepository.save(priceSale);
        return ApiResult.successResponse(entityToInfoDTO(save));
    }


    @Override
    public ApiResult<?> delete(Long id) {
        PriceSale sale = getByIdOrElseThrow(id);
        priceSaleRepository.delete(sale);
        return ApiResult.successResponse("Success");
    }

    @Override
    public void check(Basket basket) {
        Date date = new Date(System.currentTimeMillis());
        Date datePlusOne = new Date(System.currentTimeMillis() + 86400000);
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        Optional<Sale> sale = saleRepository.getSaleByCurrentTime(date,timestamp,date,datePlusOne);
        if (sale.isEmpty())
            return;
        Optional<PriceSale> priceSaleOptional = priceSaleRepository.getBySaleIdAndPriceLessThanEqual(
                sale.get().getId(),
                basket.getPrice()
        );
        if (priceSaleOptional.isEmpty()) {
            return;
        } else {
            PriceSale priceSale = priceSaleOptional.get();
            if (priceSale.getDiscountTypeEnum().equals(DiscountTypeEnum.PRICE)) {
                Double finalPrice = basket.getPrice() - priceSale.getSaleAmount();
                basket.setFinalPrice(finalPrice);
            } else if (priceSale.getDiscountTypeEnum().equals(DiscountTypeEnum.PERCENT)) {
                Double finalPrice = basket.getPrice() - (basket.getPrice() * priceSale.getSaleAmount());
                basket.setFinalPrice(finalPrice);
            }
            BasketSale basketSale = new BasketSale(basket,basket.getId(),null,null,priceSale,priceSale.getId());
            basketSaleRepository.save(basketSale);
        }

        basketService.save(basket);
    }

    private PriceSaleDTO entityToInfoDTO(PriceSale sale) {
        return new PriceSaleDTO(
                sale.getId(),
                sale.getSale().getId(),
                sale.getPrice(),
                sale.getDiscountTypeEnum().name(),
                sale.getSaleAmount(),
                saleService.entityToAddDTO(sale.getSale()));
    }

    private PriceSale dTOToEntity(PriceSaleDTO dto) {
        Sale sale = saleService.getByIdOrElseThrow(dto.getSaleId());
        DiscountTypeEnum discountTypeEnum;
        if (dto.getDiscountType().equals(DiscountTypeEnum.PRICE.name())) {
            discountTypeEnum = DiscountTypeEnum.PRICE;
        } else {
            discountTypeEnum = DiscountTypeEnum.PERCENT;
        }
        return new PriceSale(sale, dto.getPrice(), discountTypeEnum, dto.getAmount());
    }

    public PriceSale getByIdOrElseThrow(Long id) {
        return priceSaleRepository.findById(id).orElseThrow(()
                -> RestException.notFound("Price sale"));
    }

    private void updateEntity(PriceSaleDTO dto, PriceSale priceSale) {
        DiscountTypeEnum discountTypeEnum;
        if (dto.getDiscountType().equals(DiscountTypeEnum.PRICE.name())) {
            discountTypeEnum = DiscountTypeEnum.PRICE;
        } else {
            discountTypeEnum = DiscountTypeEnum.PERCENT;
        }
        Sale sale = saleService.getByIdOrElseThrow(dto.getSaleId());
        priceSale.setDiscountTypeEnum(discountTypeEnum);
        priceSale.setSale(sale);
        priceSale.setPrice(dto.getPrice());
        priceSale.setSaleAmount(dto.getAmount());


    }
}

