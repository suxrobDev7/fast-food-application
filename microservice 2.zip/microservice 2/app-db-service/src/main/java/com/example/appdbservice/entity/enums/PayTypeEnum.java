package com.example.appdbservice.entity.enums;

public enum PayTypeEnum {

    CASH,
    PAYME,
    CLICK

}
