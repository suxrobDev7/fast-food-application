package com.example.appdbservice.config;

import com.example.appdbservice.entity.users.User;
import com.example.appdbservice.utils.CommonUtils;
import org.springframework.data.domain.AuditorAware;

import java.util.Optional;

public class SpringSecurityAuditorAware implements AuditorAware {


    @Override
    public Optional<Long> getCurrentAuditor() {
        User user = CommonUtils.getUserFromRequest();
        if (user != null) {
            return Optional.ofNullable(user.getId());
        }
        return Optional.empty();
    }

}
