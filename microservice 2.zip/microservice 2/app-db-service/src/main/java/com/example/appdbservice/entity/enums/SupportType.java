package com.example.appdbservice.entity.enums;

public enum SupportType {

    OFFER,
    COMPLAINT

}
