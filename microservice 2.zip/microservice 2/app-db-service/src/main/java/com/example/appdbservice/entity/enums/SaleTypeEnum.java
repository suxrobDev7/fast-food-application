package com.example.appdbservice.entity.enums;

public enum SaleTypeEnum {

    COUNT_SALE,
    PRICE_SALE

}
