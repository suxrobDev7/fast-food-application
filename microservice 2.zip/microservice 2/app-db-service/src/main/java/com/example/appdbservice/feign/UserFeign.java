package com.example.appdbservice.feign;

public class UserFeign {
}
