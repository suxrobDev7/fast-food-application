package com.example.appdbservice.entity.users;

import com.example.appdbservice.entity.template.AbsLongEntity;
import lombok.*;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity(name = "verification_code")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@SQLDelete(sql = "update verification_code set deleted = true where id = ?")
@Where(clause = "deleted=false")
public class VerificationCode extends AbsLongEntity {

    @Column(nullable = false)
    private String code;

    @Column(nullable = false)
    private String phoneNumber;

    private boolean confirmed;

}
