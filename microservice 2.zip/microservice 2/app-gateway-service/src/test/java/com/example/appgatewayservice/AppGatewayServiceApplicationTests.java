package com.example.appgatewayservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppGatewayServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
